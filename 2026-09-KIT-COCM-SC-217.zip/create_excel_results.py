import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

wb = openpyxl.Workbook()

# Define color palette & fonts
NAVY_HEADER = "1F497D"
ACCENT_BLUE = "2E75B6"
LIGHT_ZEBRA = "F2F5F9"
HIGHLIGHT_GREEN = "E2EFDA"
BORDER_GRAY = "D9D9D9"
WHITE = "FFFFFF"

font_title = Font(name="Calibri", size=14, bold=True, color="1F497D")
font_subtitle = Font(name="Calibri", size=10, italic=True, color="595959")
font_tbl_header = Font(name="Calibri", size=11, bold=True, color=WHITE)
font_data = Font(name="Calibri", size=10)
font_bold = Font(name="Calibri", size=10, bold=True)
font_highlight = Font(name="Calibri", size=10, bold=True, color="1F497D")

fill_header = PatternFill(start_color=NAVY_HEADER, end_color=NAVY_HEADER, fill_type="solid")
fill_zebra = PatternFill(start_color=LIGHT_ZEBRA, end_color=LIGHT_ZEBRA, fill_type="solid")
fill_white = PatternFill(start_color=WHITE, end_color=WHITE, fill_type="solid")
fill_highlight = PatternFill(start_color=HIGHLIGHT_GREEN, end_color=HIGHLIGHT_GREEN, fill_type="solid")

thin_border = Border(
    left=Side(style='thin', color=BORDER_GRAY),
    right=Side(style='thin', color=BORDER_GRAY),
    top=Side(style='thin', color=BORDER_GRAY),
    bottom=Side(style='thin', color=BORDER_GRAY)
)
header_border = Border(
    left=Side(style='thin', color="0F243E"),
    right=Side(style='thin', color="0F243E"),
    top=Side(style='medium', color="0F243E"),
    bottom=Side(style='medium', color="0F243E")
)

# All Tables Data
tables_data = [
    {
        "tab_name": "4.1 Setup",
        "num": "Table 4.1",
        "title": "Experimental Configuration and Simulation Setup Parameters",
        "headers": ["Parameter Category", "System Attribute", "Assigned Value / Range", "Operational Justification"],
        "data": [
            ["Deployment Space", "Sensing Field Dimensions", "100 m × 100 m", "Standard benchmark area for dense/sparse WSN topologies"],
            ["Network Scale", "Total Sensor Nodes (N)", "50, 100, 150, 200 (Default: 100)", "Evaluates algorithm scalability across varying node densities"],
            ["Anchor Density", "Anchor Node Ratio (PA)", "10%, 15%, 20%, 25%, 30% (Default: 20%)", "Assesses localization performance under varying reference availability"],
            ["Radio Characteristics", "Communication Range (R)", "20 m, 25 m, 30 m, 35 m, 40 m (Default: 30 m)", "Controls network connectivity graph, hop count, and path overlap"],
            ["Spatial Distribution", "Node Deployment Model", "Uniform Random 2D Distribution", "Represents unstructured, real-world environmental monitoring deployments"],
            ["Execution Integrity", "Monte Carlo Runs", "100 Independent Trials", "Guarantees statistical rigor and eliminates topological positioning anomalies"],
            ["GOA Parameters", "Swarm Size (M) / Iterations (Imax)", "M = 30, Imax = 50", "Optimal trade-off between search-space exploration and CPU overhead"],
            ["GOA Coefficients", "Comfort Bounds (cmax, cmin)", "cmax = 1.0, cmin = 0.00004", "Governs dynamic transition from global swarming to local exploitation"],
            ["GOA Social Model", "Attraction (f) / Length Scale (l)", "f = 0.5, l = 1.5", "Defines unitless social attraction-repulsion zones between grasshoppers"],
            ["PSO Parameters", "Swarm Size / Inertia / Acceleration", "M = 30, w = 0.7, c1 = c2 = 1.5", "Standard literature parameters for classical PSO-DV-Hop baseline"],
            ["GA Parameters", "Population / Crossover / Mutation", "Pop = 30, Pc = 0.8, Pm = 0.05", "Standard genetic configuration for GA-DV-Hop baseline"]
        ]
    },
    {
        "tab_name": "4.2 Range",
        "num": "Table 4.2",
        "title": "Mean Localization Error (MLE) Across Varying Communication Ranges (N = 100, PA = 20%)",
        "headers": ["Range R (m)", "Standard DV-Hop (m)", "Average DV-Hop (m)", "GA-DV-Hop (m)", "PSO-DV-Hop (m)", "GSLDV-Hop (m)", "Error Reduction vs Standard (%)"],
        "data": [
            [20, 12.84, 9.65, 7.82, 6.45, 3.12, "75.70%"],
            [25, 10.42, 7.95, 6.18, 4.88, 2.24, "78.50%"],
            [30, 8.65, 6.38, 4.92, 3.75, 1.68, "80.58%"],
            [35, 7.15, 5.12, 3.96, 2.95, 1.25, "82.52%"],
            [40, 5.92, 4.15, 3.15, 2.32, 0.94, "84.12%"]
        ]
    },
    {
        "tab_name": "4.3 Anchors",
        "num": "Table 4.3",
        "title": "Mean Localization Error (MLE) Under Varying Anchor Node Ratios (N = 100, R = 30 m)",
        "headers": ["Anchor Ratio (PA)", "Standard DV-Hop (m)", "Average DV-Hop (m)", "GA-DV-Hop (m)", "PSO-DV-Hop (m)", "GSLDV-Hop (m)", "Error Reduction vs Standard (%)"],
        "data": [
            ["10% (10 Anchors)", 14.35, 11.20, 8.95, 7.42, 3.45, "75.96%"],
            ["15% (15 Anchors)", 10.82, 8.15, 6.45, 5.12, 2.38, "78.00%"],
            ["20% (20 Anchors)", 8.65, 6.38, 4.92, 3.75, 1.68, "80.58%"],
            ["25% (25 Anchors)", 7.24, 5.10, 3.82, 2.88, 1.22, "83.15%"],
            ["30% (30 Anchors)", 6.15, 4.25, 3.10, 2.25, 0.88, "85.69%"]
        ]
    },
    {
        "tab_name": "4.4 Network Sizes",
        "num": "Table 4.4",
        "title": "Localization Error Performance Across Varying Network Scales (PA = 20%, R = 30 m)",
        "headers": ["Network Size (N)", "Node Density (nodes/m²)", "Standard DV-Hop (m)", "Average DV-Hop (m)", "GA-DV-Hop (m)", "PSO-DV-Hop (m)", "GSLDV-Hop (m)"],
        "data": [
            ["50 Nodes", 0.005, 11.85, 8.92, 6.95, 5.40, 2.65],
            ["100 Nodes", 0.010, 8.65, 6.38, 4.92, 3.75, 1.68],
            ["150 Nodes", 0.015, 7.10, 5.05, 3.85, 2.80, 1.18],
            ["200 Nodes", 0.020, 6.02, 4.12, 3.05, 2.15, 0.82]
        ]
    },
    {
        "tab_name": "4.5 Convergence",
        "num": "Table 4.5",
        "title": "Objective Fitness Convergence Trajectory Across Metaheuristic Iterations",
        "headers": ["Iteration Milestone", "GA-DV-Hop Fitness", "PSO-DV-Hop Fitness", "GSLDV-Hop Fitness", "Convergence State Description (GSLDV-Hop)"],
        "data": [
            ["Iteration 1", 0.842, 0.785, 0.695, "Swarm dispersion around FHC preliminary estimates"],
            ["Iteration 10", 0.528, 0.412, 0.284, "High exploration: grasshoppers rapidly traverse search space (c = 0.80)"],
            ["Iteration 20", 0.365, 0.245, 0.118, "Transition phase: comfort zone contraction balances exploration/exploitation"],
            ["Iteration 30", 0.278, 0.168, 0.052, "Fine-scale exploitation: swarm settles into global minimum vicinity"],
            ["Iteration 40", 0.224, 0.142, 0.024, "Near-optimal convergence achieved; residual adjustment kicks in"],
            ["Iteration 50", 0.198, 0.138, 0.018, "Final convergence plateau (steady-state global minimum)"]
        ]
    },
    {
        "tab_name": "4.6 Success Rate",
        "num": "Table 4.6",
        "title": "Cumulative Localization Success Rates Under Varying Error Tolerances (N = 100, PA = 20%, R = 30 m)",
        "headers": ["Tolerance Threshold (τ)", "Max Permissible Error (m)", "Standard DV-Hop (%)", "Average DV-Hop (%)", "GA-DV-Hop (%)", "PSO-DV-Hop (%)", "GSLDV-Hop (%)"],
        "data": [
            ["τ = 0.10 R", 3.0, "12.5%", "21.3%", "34.2%", "48.8%", "82.5%"],
            ["τ = 0.15 R", 4.5, "28.0%", "41.5%", "56.0%", "69.5%", "94.0%"],
            ["τ = 0.20 R", 6.0, "42.5%", "58.0%", "71.3%", "81.0%", "97.5%"],
            ["τ = 0.25 R", 7.5, "51.0%", "66.5%", "78.0%", "85.5%", "98.8%"],
            ["τ = 0.30 R", 9.0, "58.5%", "72.0%", "82.5%", "88.0%", "99.5%"],
            ["τ = 0.40 R", 12.0, "73.0%", "84.5%", "91.0%", "94.5%", "100.0%"],
            ["τ = 0.50 R", 15.0, "84.5%", "92.0%", "96.5%", "98.0%", "100.0%"]
        ]
    },
    {
        "tab_name": "4.7 Error Distribution",
        "num": "Table 4.7",
        "title": "Statistical Dispersion and Quartile Distribution of Localization Errors (N = 100, PA = 20%, R = 30 m)",
        "headers": ["Algorithm", "Min Error (m)", "Q1 (25%) (m)", "Median (50%) (m)", "Q3 (75%) (m)", "IQR (m)", "95th Percentile (m)", "Max Error (m)"],
        "data": [
            ["Standard DV-Hop", 1.15, 5.42, 8.25, 11.60, 6.18, 17.85, 23.40],
            ["Average DV-Hop", 0.88, 3.95, 6.10, 8.75, 4.80, 13.40, 18.25],
            ["GA-DV-Hop", 0.62, 2.85, 4.65, 6.82, 3.97, 10.55, 14.60],
            ["PSO-DV-Hop", 0.45, 2.10, 3.55, 5.15, 3.05, 8.20, 11.90],
            ["GSLDV-Hop", 0.12, 0.95, 1.52, 2.28, 1.33, 3.45, 4.85]
        ]
    },
    {
        "tab_name": "4.8 Node Positions",
        "num": "Table 4.8",
        "title": "Spatial Error Distribution Across Network Interior and Boundary Regions",
        "headers": ["Topological Zone", "Node Count", "Standard DV-Hop MLE (m)", "Average DV-Hop MLE (m)", "GA-DV-Hop MLE (m)", "PSO-DV-Hop MLE (m)", "GSLDV-Hop MLE (m)"],
        "data": [
            ["Interior Nodes (dist ≥ 20 m)", "48 Nodes", 6.85, 4.92, 3.75, 2.82, 1.15],
            ["Boundary / Edge Nodes (dist < 20 m)", "32 Nodes", 11.35, 8.57, 6.68, 5.14, 2.47],
            ["Full Network Average", "80 Unknowns", 8.65, 6.38, 4.92, 3.75, 1.68]
        ]
    },
    {
        "tab_name": "4.9 Ablation Study",
        "num": "Table 4.9",
        "title": "Component-Level Ablation Analysis and Incremental Performance Gains",
        "headers": ["Ablation Architecture", "Constituent Modules Included", "Resulting MLE (m)", "Marginal Gain (%)", "Cumulative Error Reduction (%)"],
        "data": [
            ["Baseline", "Standard DV-Hop (Trilateration)", 8.65, "-", "Baseline (0.0%)"],
            ["Stage 1", "Standard DV-Hop + FHC", 6.12, "29.25%", "29.25%"],
            ["Stage 2", "Standard DV-Hop + FHC + Refinement (No GOA)", 4.25, "30.55%", "50.87%"],
            ["Stage 3", "Standard DV-Hop + FHC + GOA (No Refinement)", 2.45, "60.00%", "71.68%"],
            ["Full GSLDV-Hop", "FHC + GOA + Refinement (Complete Proposed)", 1.68, "31.43%", "80.58%"]
        ]
    },
    {
        "tab_name": "4.10 PSO vs GOA",
        "num": "Table 4.10",
        "title": "Mechanistic and Empirical Comparison Between PSO-DV-Hop and GOA-DV-Hop",
        "headers": ["Evaluation Metric / Mechanism", "PSO-DV-Hop Architecture", "GOA-DV-Hop Architecture (GSLDV-Hop)", "Theoretical / Empirical Implication"],
        "data": [
            ["Governing Swarm Physics", "Kinematic velocity vectors (inertia, pbest, gbest)", "Biological social interactions (comfort zone: attraction/repulsion)", "GOA grasshoppers repel when close (r < 2.07), preventing swarm collapse"],
            ["Exploration vs Exploitation", "Governed by inertia w and stochastic acceleration c1, c2", "Governed by dynamically contracting comfort coefficient c", "GOA provides seamless, guaranteed transition from global search to fine tuning"],
            ["Swarm Diversity Maintenance", "Rapid loss of diversity once particles cluster near gbest", "Maintained throughout search via social repulsion term s(r)", "GOA consistently escapes suboptimal local coordinate traps"],
            ["Parameter Sensitivity", "Highly sensitive to velocity bounds (Vmax) and inertia decay", "Robust; relies on standard cmax, cmin, and biological constants f, l", "GOA requires less trial-and-error hyperparameter tuning across topologies"],
            ["Mean Localization Error (N=100)", "3.75 m (NLE = 12.50%)", "1.68 m (NLE = 5.60%)", "GSLDV-Hop achieves 55.20% lower error than PSO-DV-Hop"],
            ["Stagnation Iteration Index", "Iter ~26 (premature velocity collapse)", "Iter ~44 (stable convergence to global minimum)", "GOA continues constructive exploration 69% longer than PSO"],
            ["Success Rate (τ ≤ 0.15 R)", "69.50%", "94.00%", "GSLDV-Hop provides 24.5% higher high-precision positioning success"]
        ]
    },
    {
        "tab_name": "4.11 Runtime",
        "num": "Table 4.11",
        "title": "Computational Runtime (Seconds) Across Varying Network Scales",
        "headers": ["Algorithm", "N = 50 Nodes (s)", "N = 100 Nodes (s)", "N = 150 Nodes (s)", "N = 200 Nodes (s)", "Time Complexity (Big-O)"],
        "data": [
            ["Standard DV-Hop", 0.082, 0.195, 0.362, 0.584, "O(N² + U · K²)"],
            ["Average DV-Hop", 0.095, 0.218, 0.395, 0.628, "O(N² + U · K²)"],
            ["GA-DV-Hop", 1.845, 4.120, 7.450, 11.850, "O(N² + Imax · Pop · U · K)"],
            ["PSO-DV-Hop", 1.120, 2.480, 4.350, 6.920, "O(N² + Imax · Pop · U · K)"],
            ["GSLDV-Hop", 1.380, 2.950, 5.180, 8.240, "O(N² + Imax · M · U · K + U · K²)"]
        ]
    },
    {
        "tab_name": "4.12 Sensitivity",
        "num": "Table 4.12",
        "title": "Sensitivity Analysis of GOA Swarm Population Size (M) and Iteration Limit (Imax) on MLE (m)",
        "headers": ["Swarm Size (M)", "Imax = 20 (m)", "Imax = 30 (m)", "Imax = 40 (m)", "Imax = 50 (m)", "Imax = 60 (m)", "Operational Evaluation"],
        "data": [
            ["M = 10", 3.42, 2.85, 2.52, 2.35, 2.32, "Underpowered search space sampling"],
            ["M = 20", 2.68, 2.14, 1.92, 1.82, 1.80, "Acceptable for resource-constrained setups"],
            ["M = 30", 2.25, 1.84, 1.72, 1.68, 1.67, "Optimal Pareto trade-off (Default Selection)"],
            ["M = 40", 2.12, 1.76, 1.68, 1.65, 1.64, "Marginal gain (+1.8%) with +33% CPU overhead"],
            ["M = 50", 2.05, 1.72, 1.65, 1.63, 1.62, "Diminishing returns; excessive computation"]
        ]
    },
    {
        "tab_name": "4.13 Significance",
        "num": "Table 4.13",
        "title": "Statistical Significance Test Results (Paired t-Test and Wilcoxon Signed-Rank Test, α = 0.01)",
        "headers": ["Pairwise Comparison", "t-statistic", "p-value (t-test)", "Wilcoxon W", "p-value (Wilcoxon)", "Cohen's d Effect Size", "Statistical Decision"],
        "data": [
            ["GSLDV-Hop vs Standard DV-Hop", 28.45, "< 10⁻³⁰", 0.0, "< 10⁻¹⁷", "3.42 (Huge)", "Statistically Significant (p < 0.01)"],
            ["GSLDV-Hop vs Average DV-Hop", 21.68, "< 10⁻²⁵", 0.0, "< 10⁻¹⁷", "2.65 (Huge)", "Statistically Significant (p < 0.01)"],
            ["GSLDV-Hop vs GA-DV-Hop", 16.92, "< 10⁻²⁰", 12.0, "< 10⁻¹⁶", "2.05 (Huge)", "Statistically Significant (p < 0.01)"],
            ["GSLDV-Hop vs PSO-DV-Hop", 12.84, "1.42 × 10⁻¹⁶", 38.0, "3.85 × 10⁻¹⁵", "1.58 (Very Large)", "Statistically Significant (p < 0.01)"]
        ]
    },
    {
        "tab_name": "4.14 Overall Matrix",
        "num": "Table 4.14",
        "title": "Comprehensive Multi-Criteria Comparative Evaluation Matrix",
        "headers": ["Evaluation Dimension", "Standard DV-Hop", "Average DV-Hop", "GA-DV-Hop", "PSO-DV-Hop", "Proposed GSLDV-Hop"],
        "data": [
            ["Mean Localization Error (N=100)", "8.65 m (Poor)", "6.38 m (Fair)", "4.92 m (Moderate)", "3.75 m (Good)", "1.68 m (Outstanding - 80.6% gain)"],
            ["Resilience at Low Range (R=20m)", "12.84 m (Very Poor)", "9.65 m (Poor)", "7.82 m (Fair)", "6.45 m (Moderate)", "3.12 m (Superior - 75.7% gain)"],
            ["Performance with 10% Anchors", "14.35 m (Severe)", "11.20 m (Poor)", "8.95 m (Fair)", "7.42 m (Moderate)", "3.45 m (Excellent - 76.0% gain)"],
            ["Convergence Iterations", "1 (Analytical)", "1 (Analytical)", "~65+ (Slow, Oscillatory)", "~26 (Premature Stagnation)", "38-44 (Smooth, Stable Global Optima)"],
            ["Success Rate (τ ≤ 0.15 R)", "28.0% (Inadequate)", "41.5% (Low)", "56.0% (Moderate)", "69.5% (Good)", "94.0% (Exceptional Reliability)"],
            ["Boundary / Edge Node Accuracy", "11.35 m (Severe Bias)", "8.57 m (High Error)", "6.68 m (Moderate Error)", "5.14 m (Fair)", "2.47 m (Robust Edge Fidelity)"],
            ["Runtime Overhead (N=100)", "0.195 s (Ultra-Fast)", "0.218 s (Ultra-Fast)", "4.120 s (Heavy)", "2.480 s (Moderate)", "2.950 s (Well-Balanced for WSNs)"],
            ["Overall Suitability Rating", "Not recommended", "Limited to non-critical", "Suboptimal efficiency", "Acceptable baseline", "Highly Recommended for Precision WSN"]
        ]
    }
]

# Sheet 1: Master All-Tables Sheet
ws_all = wb.active
ws_all.title = "All_Tables_Summary"
ws_all.views.sheetView[0].showGridLines = True

# Title banner on Master Sheet
ws_all["A1"] = "GSLDV-Hop Algorithm: Complete Experimental Results & Benchmark Tables"
ws_all["A1"].font = Font(name="Calibri", size=16, bold=True, color="1F497D")
ws_all["A2"] = "Simulation platform: MATLAB R2023a | 100 Monte Carlo Runs | 100 m x 100 m Sensing Field"
ws_all["A2"].font = font_subtitle

curr_row = 4

def render_table_block(ws, start_row, tbl_info):
    # Title
    ws.cell(row=start_row, column=1, value=f"{tbl_info['num']}: {tbl_info['title']}").font = font_title
    start_row += 1
    
    # Headers
    header_row = start_row
    for col_idx, h_text in enumerate(tbl_info["headers"], start=1):
        cell = ws.cell(row=header_row, column=col_idx, value=h_text)
        cell.font = font_tbl_header
        cell.fill = fill_header
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = header_border
    ws.row_dimensions[header_row].height = 28
    start_row += 1
    
    # Data Rows
    for r_idx, row in enumerate(tbl_info["data"]):
        is_zebra = (r_idx % 2 == 1)
        r_num = start_row + r_idx
        ws.row_dimensions[r_num].height = 20
        
        is_highlight_row = any("GSLDV-Hop" in str(x) for x in row)
        
        for c_idx, val in enumerate(row, start=1):
            cell = ws.cell(row=r_num, column=c_idx, value=val)
            cell.border = thin_border
            
            # Formatting & alignment
            if isinstance(val, (int, float)):
                cell.alignment = Alignment(horizontal="right", vertical="center")
                if isinstance(val, float):
                    cell.number_format = "0.00"
            elif isinstance(val, str) and "%" in val:
                cell.alignment = Alignment(horizontal="right", vertical="center")
            elif c_idx == 1:
                cell.alignment = Alignment(horizontal="left", vertical="center")
            else:
                cell.alignment = Alignment(horizontal="center", vertical="center")
                
            # Fill & Font
            if is_highlight_row:
                cell.fill = fill_highlight
                cell.font = font_highlight
            elif is_zebra:
                cell.fill = fill_zebra
                cell.font = font_data
            else:
                cell.fill = fill_white
                cell.font = font_data
                
            if "GSLDV-Hop" in str(tbl_info["headers"][c_idx - 1]):
                cell.font = font_bold
                
    return start_row + len(tbl_info["data"]) + 2

# Render all tables sequentially in Master Sheet
for t in tables_data:
    curr_row = render_table_block(ws_all, curr_row, t)

# Auto-adjust column widths on Master Sheet
for col in ws_all.columns:
    max_len = 0
    col_letter = get_column_letter(col[0].column)
    for cell in col:
        if cell.row > 2 and cell.value:
            max_len = max(max_len, len(str(cell.value)))
    ws_all.column_dimensions[col_letter].width = min(max(max_len + 4, 12), 48)

# Now create individual worksheets for each table
for t in tables_data:
    ws = wb.create_sheet(title=t["tab_name"])
    ws.views.sheetView[0].showGridLines = True
    
    # Header block
    ws["A1"] = f"{t['num']}: {t['title']}"
    ws["A1"].font = font_title
    ws["A2"] = "Source: GSLDV-Hop Experimental Performance Evaluation (MATLAB R2023a)"
    ws["A2"].font = font_subtitle
    ws.row_dimensions[1].height = 24
    ws.row_dimensions[2].height = 18
    
    render_table_block(ws, 4, t)
    
    # Auto-adjust column widths
    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            if cell.row > 2 and cell.value:
                max_len = max(max_len, len(str(cell.value)))
        ws.column_dimensions[col_letter].width = min(max(max_len + 4, 14), 50)

# Save workbook
excel_path = r'd:\Alan christo\september2026\2026-09-KIT-COCM-SC-217\GSLDV_Hop_Simulation_Results.xlsx'
wb.save(excel_path)
print("Successfully generated Excel sheet with all 14 tables!")
