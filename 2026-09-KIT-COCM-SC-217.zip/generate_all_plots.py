import os
import matplotlib
import matplotlib.pyplot as plt
import numpy as np

# Exact user-requested configuration
plt.rcParams["figure.figsize"] = (11, 7)
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 18
plt.rcParams['font.weight'] = 'bold'
plt.rcParams['axes.labelweight'] = 'bold'
plt.rcParams['axes.titleweight'] = 'bold'
plt.rcParams['figure.titleweight'] = 'bold'

output_dir = r"d:\Alan christo\september2026\2026-09-KIT-COCM-SC-217\plots"
os.makedirs(output_dir, exist_ok=True)

colors = {
    'Standard DV-Hop': '#C0392B',    # Deep Red
    'Average DV-Hop': '#D35400',     # Rust Orange
    'GA-DV-Hop': '#8E44AD',          # Purple
    'PSO-DV-Hop': '#2980B9',         # Navy Blue
    'GSLDV-Hop': '#27AE60'           # Vibrant Green
}

markers = {
    'Standard DV-Hop': 's',
    'Average DV-Hop': '^',
    'GA-DV-Hop': 'D',
    'PSO-DV-Hop': 'v',
    'GSLDV-Hop': 'o'
}

DPI = 800

# ==============================================================================
# Plot 1: Table 4.2 - Communication Range vs MLE
# ==============================================================================
fig, ax = plt.subplots(figsize=(11, 7))
ranges = [20, 25, 30, 35, 40]
mle_std = [12.84, 10.42, 8.65, 7.15, 5.92]
mle_avg = [9.65, 7.95, 6.38, 5.12, 4.15]
mle_ga  = [7.82, 6.18, 4.92, 3.96, 3.15]
mle_pso = [6.45, 4.88, 3.75, 2.95, 2.32]
mle_prop= [3.12, 2.24, 1.68, 1.25, 0.94]

ax.plot(ranges, mle_std, marker=markers['Standard DV-Hop'], color=colors['Standard DV-Hop'], linewidth=2.8, markersize=10, label='Standard DV-Hop')
ax.plot(ranges, mle_avg, marker=markers['Average DV-Hop'], color=colors['Average DV-Hop'], linewidth=2.8, markersize=10, label='Average DV-Hop')
ax.plot(ranges, mle_ga,  marker=markers['GA-DV-Hop'], color=colors['GA-DV-Hop'], linewidth=2.8, markersize=10, label='GA-DV-Hop')
ax.plot(ranges, mle_pso, marker=markers['PSO-DV-Hop'], color=colors['PSO-DV-Hop'], linewidth=2.8, markersize=10, label='PSO-DV-Hop')
ax.plot(ranges, mle_prop, marker=markers['GSLDV-Hop'], color=colors['GSLDV-Hop'], linewidth=3.5, markersize=12, label='Proposed GSLDV-Hop')

ax.set_xlabel('Communication Range R (meters)', fontsize=19, fontweight='bold', labelpad=10)
ax.set_ylabel('Mean Localization Error (meters)', fontsize=19, fontweight='bold', labelpad=10)
ax.set_title('Localization Error vs. Communication Range (N = 100, PA = 20%)', fontsize=20, fontweight='bold', pad=15)
ax.set_xticks(ranges)
ax.grid(False)
ax.legend(frameon=True, edgecolor='black', fancybox=False, fontsize=15, loc='upper right')
plt.tight_layout()
p1_path = os.path.join(output_dir, "Fig_4_2_MLE_vs_Communication_Range.png")
plt.savefig(p1_path, dpi=DPI)
plt.close()
print("Saved:", p1_path)

# ==============================================================================
# Plot 2: Table 4.3 - Anchor Node Density vs MLE
# ==============================================================================
fig, ax = plt.subplots(figsize=(11, 7))
anchors = [10, 15, 20, 25, 30]
mle_std = [14.35, 10.82, 8.65, 7.24, 6.15]
mle_avg = [11.20, 8.15, 6.38, 5.10, 4.25]
mle_ga  = [8.95, 6.45, 4.92, 3.82, 3.10]
mle_pso = [7.42, 5.12, 3.75, 2.88, 2.25]
mle_prop= [3.45, 2.38, 1.68, 1.22, 0.88]

ax.plot(anchors, mle_std, marker=markers['Standard DV-Hop'], color=colors['Standard DV-Hop'], linewidth=2.8, markersize=10, label='Standard DV-Hop')
ax.plot(anchors, mle_avg, marker=markers['Average DV-Hop'], color=colors['Average DV-Hop'], linewidth=2.8, markersize=10, label='Average DV-Hop')
ax.plot(anchors, mle_ga,  marker=markers['GA-DV-Hop'], color=colors['GA-DV-Hop'], linewidth=2.8, markersize=10, label='GA-DV-Hop')
ax.plot(anchors, mle_pso, marker=markers['PSO-DV-Hop'], color=colors['PSO-DV-Hop'], linewidth=2.8, markersize=10, label='PSO-DV-Hop')
ax.plot(anchors, mle_prop, marker=markers['GSLDV-Hop'], color=colors['GSLDV-Hop'], linewidth=3.5, markersize=12, label='Proposed GSLDV-Hop')

ax.set_xlabel('Anchor Node Percentage PA (%)', fontsize=19, fontweight='bold', labelpad=10)
ax.set_ylabel('Mean Localization Error (meters)', fontsize=19, fontweight='bold', labelpad=10)
ax.set_title('Localization Error vs. Anchor Node Ratio (N = 100, R = 30 m)', fontsize=20, fontweight='bold', pad=15)
ax.set_xticks(anchors)
ax.grid(False)
ax.legend(frameon=True, edgecolor='black', fancybox=False, fontsize=15, loc='upper right')
plt.tight_layout()
p2_path = os.path.join(output_dir, "Fig_4_3_MLE_vs_Anchor_Node_Ratio.png")
plt.savefig(p2_path, dpi=DPI)
plt.close()
print("Saved:", p2_path)

# ==============================================================================
# Plot 3: Table 4.4 - Network Scale vs MLE
# ==============================================================================
fig, ax = plt.subplots(figsize=(11, 7))
nodes = [50, 100, 150, 200]
x = np.arange(len(nodes))
w = 0.15

v_std = [11.85, 8.65, 7.10, 6.02]
v_avg = [8.92, 6.38, 5.05, 4.12]
v_ga  = [6.95, 4.92, 3.85, 3.05]
v_pso = [5.40, 3.75, 2.80, 2.15]
v_prop= [2.65, 1.68, 1.18, 0.82]

ax.bar(x - 2*w, v_std, width=w, color=colors['Standard DV-Hop'], edgecolor='black', label='Standard DV-Hop')
ax.bar(x - 1*w, v_avg, width=w, color=colors['Average DV-Hop'], edgecolor='black', label='Average DV-Hop')
ax.bar(x,       v_ga,  width=w, color=colors['GA-DV-Hop'], edgecolor='black', label='GA-DV-Hop')
ax.bar(x + 1*w, v_pso, width=w, color=colors['PSO-DV-Hop'], edgecolor='black', label='PSO-DV-Hop')
ax.bar(x + 2*w, v_prop, width=w, color=colors['GSLDV-Hop'], edgecolor='black', label='Proposed GSLDV-Hop')

ax.set_xlabel('Total Number of Sensor Nodes (Network Scale N)', fontsize=19, fontweight='bold', labelpad=10)
ax.set_ylabel('Mean Localization Error (meters)', fontsize=19, fontweight='bold', labelpad=10)
ax.set_title('Localization Error Across Network Scales (PA = 20%, R = 30 m)', fontsize=20, fontweight='bold', pad=15)
ax.set_xticks(x)
ax.set_xticklabels([f'{n} Nodes' for n in nodes], fontweight='bold')
ax.grid(False)
ax.legend(frameon=True, edgecolor='black', fancybox=False, fontsize=15, loc='upper right')
plt.tight_layout()
p3_path = os.path.join(output_dir, "Fig_4_4_MLE_vs_Network_Scale.png")
plt.savefig(p3_path, dpi=DPI)
plt.close()
print("Saved:", p3_path)

# ==============================================================================
# Plot 4: Table 4.5 - Objective Fitness Convergence Trajectory
# ==============================================================================
fig, ax = plt.subplots(figsize=(11, 7))
iters = [1, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50]
fit_ga  = [0.842, 0.675, 0.528, 0.435, 0.365, 0.312, 0.278, 0.248, 0.224, 0.208, 0.198]
fit_pso = [0.785, 0.560, 0.412, 0.315, 0.245, 0.195, 0.168, 0.150, 0.142, 0.139, 0.138]
fit_prop= [0.695, 0.450, 0.284, 0.182, 0.118, 0.075, 0.052, 0.034, 0.024, 0.019, 0.018]

ax.plot(iters, fit_ga,  marker=markers['GA-DV-Hop'], color=colors['GA-DV-Hop'], linewidth=2.8, markersize=9, label='GA-DV-Hop')
ax.plot(iters, fit_pso, marker=markers['PSO-DV-Hop'], color=colors['PSO-DV-Hop'], linewidth=2.8, markersize=9, label='PSO-DV-Hop')
ax.plot(iters, fit_prop, marker=markers['GSLDV-Hop'], color=colors['GSLDV-Hop'], linewidth=3.5, markersize=11, label='Proposed GSLDV-Hop')

ax.set_xlabel('Optimization Iterations', fontsize=19, fontweight='bold', labelpad=10)
ax.set_ylabel('Objective Fitness (Residual Error)', fontsize=19, fontweight='bold', labelpad=10)
ax.set_title('Fitness Convergence Curves Over 50 Iterations (N = 100, R = 30 m)', fontsize=20, fontweight='bold', pad=15)
ax.set_xticks([1, 10, 20, 30, 40, 50])
ax.grid(False)
ax.legend(frameon=True, edgecolor='black', fancybox=False, fontsize=16, loc='upper right')
plt.tight_layout()
p4_path = os.path.join(output_dir, "Fig_4_5_Convergence_Curves.png")
plt.savefig(p4_path, dpi=DPI)
plt.close()
print("Saved:", p4_path)

# ==============================================================================
# Plot 5: Table 4.6 - Localization Success Rate vs Tolerance Threshold
# ==============================================================================
fig, ax = plt.subplots(figsize=(11, 7))
tau_labels = ['0.10 R\n(3.0 m)', '0.15 R\n(4.5 m)', '0.20 R\n(6.0 m)', '0.25 R\n(7.5 m)', '0.30 R\n(9.0 m)', '0.40 R\n(12.0 m)', '0.50 R\n(15.0 m)']
tau_x = [0.10, 0.15, 0.20, 0.25, 0.30, 0.40, 0.50]
sr_std = [12.5, 28.0, 42.5, 51.0, 58.5, 73.0, 84.5]
sr_avg = [21.3, 41.5, 58.0, 66.5, 72.0, 84.5, 92.0]
sr_ga  = [34.2, 56.0, 71.3, 78.0, 82.5, 91.0, 96.5]
sr_pso = [48.8, 69.5, 81.0, 85.5, 88.0, 94.5, 98.0]
sr_prop= [82.5, 94.0, 97.5, 98.8, 99.5, 100.0, 100.0]

ax.plot(tau_x, sr_std, marker=markers['Standard DV-Hop'], color=colors['Standard DV-Hop'], linewidth=2.8, markersize=10, label='Standard DV-Hop')
ax.plot(tau_x, sr_avg, marker=markers['Average DV-Hop'], color=colors['Average DV-Hop'], linewidth=2.8, markersize=10, label='Average DV-Hop')
ax.plot(tau_x, sr_ga,  marker=markers['GA-DV-Hop'], color=colors['GA-DV-Hop'], linewidth=2.8, markersize=10, label='GA-DV-Hop')
ax.plot(tau_x, sr_pso, marker=markers['PSO-DV-Hop'], color=colors['PSO-DV-Hop'], linewidth=2.8, markersize=10, label='PSO-DV-Hop')
ax.plot(tau_x, sr_prop, marker=markers['GSLDV-Hop'], color=colors['GSLDV-Hop'], linewidth=3.5, markersize=12, label='Proposed GSLDV-Hop')

ax.set_xlabel('Permissible Error Tolerance Threshold (τ · R)', fontsize=19, fontweight='bold', labelpad=10)
ax.set_ylabel('Localization Success Rate (%)', fontsize=19, fontweight='bold', labelpad=10)
ax.set_title('Cumulative Localization Success Rate Comparison (N = 100, R = 30 m)', fontsize=20, fontweight='bold', pad=15)
ax.set_xticks(tau_x)
ax.set_xticklabels(tau_labels, fontsize=14, fontweight='bold')
ax.set_ylim(5, 105)
ax.grid(False)
ax.legend(frameon=True, edgecolor='black', fancybox=False, fontsize=15, loc='lower right')
plt.tight_layout()
p5_path = os.path.join(output_dir, "Fig_4_6_Success_Rate_Comparison.png")
plt.savefig(p5_path, dpi=DPI)
plt.close()
print("Saved:", p5_path)

# ==============================================================================
# Plot 6: Table 4.7 - Error Distribution & Statistical Dispersion
# ==============================================================================
fig, ax = plt.subplots(figsize=(11, 7))
algos = ['Standard\nDV-Hop', 'Average\nDV-Hop', 'GA-DV-Hop', 'PSO-DV-Hop', 'GSLDV-Hop']
bx_data = [
    {'med': 8.25, 'q1': 5.42, 'q3': 11.60, 'whislo': 1.15, 'whishi': 17.85, 'fliers': [23.40]},
    {'med': 6.10, 'q1': 3.95, 'q3': 8.75,  'whislo': 0.88, 'whishi': 13.40, 'fliers': [18.25]},
    {'med': 4.65, 'q1': 2.85, 'q3': 6.82,  'whislo': 0.62, 'whishi': 10.55, 'fliers': [14.60]},
    {'med': 3.55, 'q1': 2.10, 'q3': 5.15,  'whislo': 0.45, 'whishi': 8.20,  'fliers': [11.90]},
    {'med': 1.52, 'q1': 0.95, 'q3': 2.28,  'whislo': 0.12, 'whishi': 3.45,  'fliers': [4.85]}
]

box_colors = [colors['Standard DV-Hop'], colors['Average DV-Hop'], colors['GA-DV-Hop'], colors['PSO-DV-Hop'], colors['GSLDV-Hop']]
bplots = ax.bxp(bx_data, showmeans=False, patch_artist=True, widths=0.5)

for patch, c in zip(bplots['boxes'], box_colors):
    patch.set_facecolor(c)
    patch.set_alpha(0.85)
    patch.set_edgecolor('black')
    patch.set_linewidth(1.8)

for median in bplots['medians']:
    median.set_color('black')
    median.set_linewidth(2.5)

for whisker in bplots['whiskers']:
    whisker.set_color('black')
    whisker.set_linewidth(1.8)
    whisker.set_linestyle('--')

for cap in bplots['caps']:
    cap.set_color('black')
    cap.set_linewidth(2.0)

ax.set_xlabel('Localization Algorithm', fontsize=19, fontweight='bold', labelpad=10)
ax.set_ylabel('Localization Error Dispersion (meters)', fontsize=19, fontweight='bold', labelpad=10)
ax.set_title('Statistical Error Distribution: Quartiles & Bounds (N = 100, R = 30 m)', fontsize=20, fontweight='bold', pad=15)
ax.set_xticklabels(algos, fontsize=16, fontweight='bold')
ax.grid(False)
plt.tight_layout()
p6_path = os.path.join(output_dir, "Fig_4_7_Error_Distribution_Boxplots.png")
plt.savefig(p6_path, dpi=DPI)
plt.close()
print("Saved:", p6_path)

# ==============================================================================
# Plot 7: Table 4.8 - Spatial Error: Interior vs Boundary Nodes
# ==============================================================================
fig, ax = plt.subplots(figsize=(11, 7))
zones = ['Interior Nodes\n(dist ≥ 20 m)', 'Boundary / Edge Nodes\n(dist < 20 m)', 'Full Network\nAverage']
x = np.arange(len(zones))
w = 0.15

z_std = [6.85, 11.35, 8.65]
z_avg = [4.92, 8.57, 6.38]
z_ga  = [3.75, 6.68, 4.92]
z_pso = [2.82, 5.14, 3.75]
z_prop= [1.15, 2.47, 1.68]

ax.bar(x - 2*w, z_std, width=w, color=colors['Standard DV-Hop'], edgecolor='black', label='Standard DV-Hop')
ax.bar(x - 1*w, z_avg, width=w, color=colors['Average DV-Hop'], edgecolor='black', label='Average DV-Hop')
ax.bar(x,       z_ga,  width=w, color=colors['GA-DV-Hop'], edgecolor='black', label='GA-DV-Hop')
ax.bar(x + 1*w, z_pso, width=w, color=colors['PSO-DV-Hop'], edgecolor='black', label='PSO-DV-Hop')
ax.bar(x + 2*w, z_prop, width=w, color=colors['GSLDV-Hop'], edgecolor='black', label='Proposed GSLDV-Hop')

ax.set_xlabel('Spatial Topological Zone in Deployment Grid', fontsize=19, fontweight='bold', labelpad=10)
ax.set_ylabel('Mean Localization Error (meters)', fontsize=19, fontweight='bold', labelpad=10)
ax.set_title('Interior vs. Boundary Node Localization Accuracy (100 m × 100 m Area)', fontsize=20, fontweight='bold', pad=15)
ax.set_xticks(x)
ax.set_xticklabels(zones, fontsize=15, fontweight='bold')
ax.grid(False)
ax.legend(frameon=True, edgecolor='black', fancybox=False, fontsize=15, loc='upper right')
plt.tight_layout()
p7_path = os.path.join(output_dir, "Fig_4_8_Interior_vs_Boundary_Error.png")
plt.savefig(p7_path, dpi=DPI)
plt.close()
print("Saved:", p7_path)

# ==============================================================================
# Plot 8: Table 4.9 - Ablation Study
# ==============================================================================
fig, ax1 = plt.subplots(figsize=(11, 7))
stages = ['Standard\nDV-Hop', '+ FHC', '+ FHC +\nRefinement', '+ FHC +\nGOA', 'Full GSLDV-Hop\n(Proposed)']
mle_vals = [8.65, 6.12, 4.25, 2.45, 1.68]
red_vals = [0.0, 29.25, 50.87, 71.68, 80.58]

x = np.arange(len(stages))
color_bar = '#2E86C1'
bars = ax1.bar(x, mle_vals, width=0.45, color=color_bar, edgecolor='black', label='Mean Localization Error (m)')
ax1.set_xlabel('Architectural Ablation Stages', fontsize=19, fontweight='bold', labelpad=10)
ax1.set_ylabel('Mean Localization Error (meters)', color=color_bar, fontsize=19, fontweight='bold', labelpad=10)
ax1.tick_params(axis='y', labelcolor=color_bar)
ax1.set_xticks(x)
ax1.set_xticklabels(stages, fontsize=14, fontweight='bold')
ax1.grid(False)

for bar in bars:
    yval = bar.get_height()
    ax1.text(bar.get_x() + bar.get_width()/2.0, yval + 0.15, f'{yval:.2f} m', ha='center', va='bottom', fontsize=14, fontweight='bold')

ax2 = ax1.twinx()
color_line = '#C0392B'
ax2.plot(x, red_vals, color=color_line, marker='o', linewidth=3.2, markersize=11, label='Cumulative Error Reduction (%)')
ax2.set_ylabel('Cumulative Error Reduction (%)', color=color_line, fontsize=19, fontweight='bold', labelpad=10)
ax2.tick_params(axis='y', labelcolor=color_line)
ax2.set_ylim(-5, 100)
ax2.grid(False)

for i, val in enumerate(red_vals):
    if i > 0:
        ax2.text(x[i], val + 3.0, f'{val:.1f}%', ha='center', va='bottom', fontsize=14, fontweight='bold', color=color_line)

plt.title('Ablation Analysis: Incremental Module Performance Gain', fontsize=20, fontweight='bold', pad=15)
plt.tight_layout()
p8_path = os.path.join(output_dir, "Fig_4_9_Ablation_Analysis.png")
plt.savefig(p8_path, dpi=DPI)
plt.close()
print("Saved:", p8_path)

# ==============================================================================
# Plot 9: Table 4.10 - PSO vs GOA Head-to-Head Comparison
# ==============================================================================
fig, ax = plt.subplots(figsize=(11, 7))
metrics = ['Mean Error\n(meters)', 'Normalized Error\nNLE (%)', 'Stagnation Iteration\n(Index / 10)', 'High-Prec Success\n(τ ≤ 0.15 R) (%)']
pso_scores = [3.75, 12.50, 2.60, 69.50]
goa_scores = [1.68, 5.60, 4.40, 94.00]

x = np.arange(len(metrics))
w = 0.35

rects1 = ax.bar(x - w/2, pso_scores, width=w, color=colors['PSO-DV-Hop'], edgecolor='black', label='PSO-DV-Hop')
rects2 = ax.bar(x + w/2, goa_scores, width=w, color=colors['GSLDV-Hop'], edgecolor='black', label='GOA-DV-Hop (GSLDV-Hop)')

for rect in rects1:
    h = rect.get_height()
    ax.text(rect.get_x() + rect.get_width()/2.0, h + 1.2, f'{h:.1f}', ha='center', va='bottom', fontsize=13, fontweight='bold')

for rect in rects2:
    h = rect.get_height()
    ax.text(rect.get_x() + rect.get_width()/2.0, h + 1.2, f'{h:.1f}', ha='center', va='bottom', fontsize=13, fontweight='bold')

ax.set_xlabel('Key Performance Indicators (KPIs)', fontsize=19, fontweight='bold', labelpad=10)
ax.set_ylabel('Metric Value', fontsize=19, fontweight='bold', labelpad=10)
ax.set_title('Head-to-Head Performance: PSO-DV-Hop vs. GOA-DV-Hop', fontsize=20, fontweight='bold', pad=15)
ax.set_xticks(x)
ax.set_xticklabels(metrics, fontsize=15, fontweight='bold')
ax.set_ylim(0, 110)
ax.grid(False)
ax.legend(frameon=True, edgecolor='black', fancybox=False, fontsize=16, loc='upper left')
plt.tight_layout()
p9_path = os.path.join(output_dir, "Fig_4_10_PSO_vs_GOA_HeadToHead.png")
plt.savefig(p9_path, dpi=DPI)
plt.close()
print("Saved:", p9_path)

# ==============================================================================
# Plot 10: Table 4.11 - Computational Runtime
# ==============================================================================
fig, ax = plt.subplots(figsize=(11, 7))
nodes = [50, 100, 150, 200]
t_std = [0.082, 0.195, 0.362, 0.584]
t_avg = [0.095, 0.218, 0.395, 0.628]
t_ga  = [1.845, 4.120, 7.450, 11.850]
t_pso = [1.120, 2.480, 4.350, 6.920]
t_prop= [1.380, 2.950, 5.180, 8.240]

ax.plot(nodes, t_std, marker=markers['Standard DV-Hop'], color=colors['Standard DV-Hop'], linewidth=2.8, markersize=10, label='Standard DV-Hop')
ax.plot(nodes, t_avg, marker=markers['Average DV-Hop'], color=colors['Average DV-Hop'], linewidth=2.8, markersize=10, label='Average DV-Hop')
ax.plot(nodes, t_pso, marker=markers['PSO-DV-Hop'], color=colors['PSO-DV-Hop'], linewidth=2.8, markersize=10, label='PSO-DV-Hop')
ax.plot(nodes, t_prop, marker=markers['GSLDV-Hop'], color=colors['GSLDV-Hop'], linewidth=3.5, markersize=12, label='Proposed GSLDV-Hop')
ax.plot(nodes, t_ga,  marker=markers['GA-DV-Hop'], color=colors['GA-DV-Hop'], linewidth=2.8, markersize=10, label='GA-DV-Hop')

ax.set_xlabel('Total Number of Sensor Nodes (Network Scale N)', fontsize=19, fontweight='bold', labelpad=10)
ax.set_ylabel('Total Execution Runtime (seconds)', fontsize=19, fontweight='bold', labelpad=10)
ax.set_title('Computational Runtime vs. Network Scale (PA = 20%, R = 30 m)', fontsize=20, fontweight='bold', pad=15)
ax.set_xticks(nodes)
ax.grid(False)
ax.legend(frameon=True, edgecolor='black', fancybox=False, fontsize=15, loc='upper left')
plt.tight_layout()
p10_path = os.path.join(output_dir, "Fig_4_11_Computational_Runtime.png")
plt.savefig(p10_path, dpi=DPI)
plt.close()
print("Saved:", p10_path)

# ==============================================================================
# Plot 11: Table 4.12 - Parameter Sensitivity (Swarm Size M vs Iterations Imax)
# ==============================================================================
fig, ax = plt.subplots(figsize=(11, 7))
swarm_sizes = ['M = 10', 'M = 20', 'M = 30\n(Default)', 'M = 40', 'M = 50']
x = np.arange(len(swarm_sizes))
w = 0.16

s_iter20 = [3.42, 2.68, 2.25, 2.12, 2.05]
s_iter30 = [2.85, 2.14, 1.84, 1.76, 1.72]
s_iter40 = [2.52, 1.92, 1.72, 1.68, 1.65]
s_iter50 = [2.35, 1.82, 1.68, 1.65, 1.63]
s_iter60 = [2.32, 1.80, 1.67, 1.64, 1.62]

ax.bar(x - 2*w, s_iter20, width=w, color='#AED6F1', edgecolor='black', label='Imax = 20')
ax.bar(x - 1*w, s_iter30, width=w, color='#5DADE2', edgecolor='black', label='Imax = 30')
ax.bar(x,       s_iter40, width=w, color='#2E86C1', edgecolor='black', label='Imax = 40')
ax.bar(x + 1*w, s_iter50, width=w, color='#1B4F72', edgecolor='black', label='Imax = 50 (Selected)')
ax.bar(x + 2*w, s_iter60, width=w, color='#145A32', edgecolor='black', label='Imax = 60')

ax.set_xlabel('GOA Swarm Population Size (M)', fontsize=19, fontweight='bold', labelpad=10)
ax.set_ylabel('Mean Localization Error (meters)', fontsize=19, fontweight='bold', labelpad=10)
ax.set_title('Sensitivity Analysis: Swarm Size (M) vs. Max Iterations (Imax)', fontsize=20, fontweight='bold', pad=15)
ax.set_xticks(x)
ax.set_xticklabels(swarm_sizes, fontsize=15, fontweight='bold')
ax.set_ylim(0, 4.0)
ax.grid(False)
ax.legend(frameon=True, edgecolor='black', fancybox=False, fontsize=14, loc='upper right', ncol=2)
plt.tight_layout()
p11_path = os.path.join(output_dir, "Fig_4_12_Parameter_Sensitivity.png")
plt.savefig(p11_path, dpi=DPI)
plt.close()
print("Saved:", p11_path)

# ==============================================================================
# Plot 12: Table 4.13 - Statistical Significance (t-statistic & Cohen's d)
# ==============================================================================
fig, ax1 = plt.subplots(figsize=(11, 7))
comps = ['GSLDV-Hop vs.\nStandard DV-Hop', 'GSLDV-Hop vs.\nAverage DV-Hop', 'GSLDV-Hop vs.\nGA-DV-Hop', 'GSLDV-Hop vs.\nPSO-DV-Hop']
t_stats = [28.45, 21.68, 16.92, 12.84]
cohens_d = [3.42, 2.65, 2.05, 1.58]

x = np.arange(len(comps))
color_t = '#1F497D'
bars = ax1.bar(x, t_stats, width=0.45, color=color_t, edgecolor='black', label='Paired t-Statistic')
ax1.set_xlabel('Pairwise Algorithmic Comparisons (100 Monte Carlo Trials)', fontsize=19, fontweight='bold', labelpad=10)
ax1.set_ylabel('Paired Student t-Statistic (df = 99)', color=color_t, fontsize=19, fontweight='bold', labelpad=10)
ax1.tick_params(axis='y', labelcolor=color_t)
ax1.set_xticks(x)
ax1.set_xticklabels(comps, fontsize=14, fontweight='bold')
ax1.set_ylim(0, 35)
ax1.grid(False)

for bar in bars:
    yval = bar.get_height()
    ax1.text(bar.get_x() + bar.get_width()/2.0, yval + 0.6, f't = {yval:.2f}\n(p < 10⁻¹⁶)', ha='center', va='bottom', fontsize=12, fontweight='bold', color=color_t)

ax2 = ax1.twinx()
color_d = '#D35400'
ax2.plot(x, cohens_d, color=color_d, marker='D', linewidth=3.2, markersize=11, label="Cohen's d Effect Size")
ax2.set_ylabel("Cohen's d (Standardized Effect Size)", color=color_d, fontsize=19, fontweight='bold', labelpad=10)
ax2.tick_params(axis='y', labelcolor=color_d)
ax2.axhline(0.8, color='gray', linestyle=':', linewidth=2, label='Large Effect Threshold (d = 0.8)')
ax2.set_ylim(0, 4.5)
ax2.grid(False)

for i, val in enumerate(cohens_d):
    ax2.text(x[i], val + 0.15, f'd = {val:.2f}', ha='center', va='bottom', fontsize=14, fontweight='bold', color=color_d)

plt.title('Statistical Hypothesis Testing: t-Statistics & Effect Sizes (α = 0.01)', fontsize=20, fontweight='bold', pad=15)
plt.tight_layout()
p12_path = os.path.join(output_dir, "Fig_4_13_Statistical_Significance.png")
plt.savefig(p12_path, dpi=DPI)
plt.close()
print("Saved:", p12_path)

# ==============================================================================
# Plot 13: Table 4.14 - Overall Multi-Criteria Radar / Spider Chart
# ==============================================================================
categories = ['Low Localization Error', 'Sparse Range Resilience', 'Anchor Scarcity Robustness', 'High Convergence Speed', 'High-Precision Success', 'Edge-Node Fidelity']
N_cat = len(categories)

# Normalized benchmark scores on a 0 - 100 scale (100 = Best)
score_std =  [15, 12, 10, 85, 28, 20]
score_avg =  [35, 30, 25, 85, 41, 35]
score_ga  =  [55, 50, 45, 40, 56, 50]
score_pso =  [70, 65, 60, 55, 69, 65]
score_prop = [96, 92, 90, 88, 95, 92]

angles = [n / float(N_cat) * 2 * np.pi for n in range(N_cat)]
angles += angles[:1]

fig, ax = plt.subplots(figsize=(11, 7), subplot_kw=dict(polar=True))

def add_radar_trace(scores, label, color):
    vals = scores + scores[:1]
    ax.plot(angles, vals, color=color, linewidth=2.6, label=label)
    ax.fill(angles, vals, color=color, alpha=0.10)

add_radar_trace(score_std, 'Standard DV-Hop', colors['Standard DV-Hop'])
add_radar_trace(score_avg, 'Average DV-Hop', colors['Average DV-Hop'])
add_radar_trace(score_ga,  'GA-DV-Hop', colors['GA-DV-Hop'])
add_radar_trace(score_pso, 'PSO-DV-Hop', colors['PSO-DV-Hop'])
add_radar_trace(score_prop, 'Proposed GSLDV-Hop', colors['GSLDV-Hop'])

ax.set_theta_offset(np.pi / 2)
ax.set_theta_direction(-1)
ax.set_xticks(angles[:-1])
ax.set_xticklabels(categories, fontsize=13, fontweight='bold')
ax.set_rlabel_position(0)
ax.set_yticks([20, 40, 60, 80, 100])
ax.set_yticklabels(["20", "40", "60", "80", "100"], fontsize=11, fontweight='bold', color='gray')
ax.set_ylim(0, 105)
ax.grid(False)

plt.title('Overall Multi-Criteria Performance Comparison Scorecard', fontsize=20, fontweight='bold', pad=25)
ax.legend(loc='upper right', bbox_to_anchor=(1.35, 1.1), frameon=True, edgecolor='black', fancybox=False, fontsize=14)
plt.tight_layout()
p13_path = os.path.join(output_dir, "Fig_4_14_Overall_Radar_Comparison.png")
plt.savefig(p13_path, dpi=DPI)
plt.close()
print("Saved:", p13_path)

print("All 13 plots generated successfully at dpi=800 with no grids and bold Times New Roman font!")
